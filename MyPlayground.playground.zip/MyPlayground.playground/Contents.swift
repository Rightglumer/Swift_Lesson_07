import Cocoa

enum SaveBoatError : Error {
    case outOfPlace
    case boatCorrupted
    case boatNotFound
}

class Boat {
    var placeCount : Int
    init(placeCount : Int){
        self.placeCount = placeCount;
    }
    
    func saveGuest() throws {
        guard placeCount > 0 else {
            throw SaveBoatError.outOfPlace
        }
        placeCount -= 1;
        print("Free places: \(placeCount)")
    }
    
    func isFull() -> Bool {
        return placeCount == 0;
    }
}

class Ship {
    var saveBoatsCount : Int
    var saveBoat = [Boat]()
    
    init(saveBoatsCount : Int, placeInBoat : Int) {
        self.saveBoatsCount = saveBoatsCount;
        for _ in 0...(saveBoatsCount - 1) {
            saveBoat.append(Boat(placeCount: placeInBoat))
        }
    }
    
    func getBoatNumber() throws -> Int{
        guard saveBoat.count > 0 else {
            throw SaveBoatError.boatNotFound
        }
        return saveBoat.count - 1;
    }
    
    func saveMe() throws -> Bool {
        do {
            try getBoatNumber();
        } catch SaveBoatError.boatNotFound {
            print("There are no boats. You will die!")
                
        }
        do {
            try saveBoat[getBoatNumber()].saveGuest();
            if try saveBoat[getBoatNumber()].isFull() {
                print("Boat is full")
                saveBoat.removeLast();
                print("Boats left: \(saveBoat.count)")
            }
        } catch SaveBoatError.outOfPlace {
            print("No places in boat. You will die!")
        }
        saveBoatsCount -= 1;
        return true;
    }
}

var titanik = Ship(saveBoatsCount: 1, placeInBoat: 3);

do {
    try titanik.saveMe()
    try titanik.saveMe()
    try titanik.saveMe()
    try titanik.saveMe()
} catch {
    print("You will die!!!")
}
